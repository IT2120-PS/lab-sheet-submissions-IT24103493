setwd("C:\\Users\\it24103493\\Desktop\\IT24103493")

branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")

str(branch_data)
summary(branch_data)

boxplot(branch_data$Sales_X1,main="Boxplot for Sales",ylab="Sales")

summary(branch_data$Advertising_X2)
quantile(branch_data$Advertising_X2)


IQR(branch_data$Advertising_X2)

get_outlier<-function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  print(paste("Lower Bound =",lb))
  print(paste("Upper Bound =",ub))
  print(paste("outlier:",paste(sort(z[z<lb | z>ub]),collapse = ",")))
}
get_outlier(branch_data$Years_X3)
  
